<!--cindy nordiansyah-->
<?php
	$uri2 = $this->uri->segment(2);
	if ($uri2 == 'setting_page')
		$uri3 = '';
	//else if ($uri2 == 'agent_page_by_status')
	//	$uri3 = $this->uri->segment(3);
	
?>
<!--slidemenu--> 
<div class="navigator">
	<div class="pagetitle"></div>
	<div id="top_menu">
		<ul class="sub0 sortleftmenu" id="ul_0" >
			<?php echo ($uri2=='setting_bank_page' ? '<li id="grp_5" class="selected">' : '<li id="grp_5">');?>
				<span >Airlines
					<div class="nextrow">&nbsp;</div>
				</span>
				<ul class="sub1 sortleftmenu" id="ul_394" >
					<li id="grp_423">
						<a href="<?php echo base_url();?>index.php/admin/assets_airlines/airlines" >Airlines</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_airlines/rute" >Airlines Rute</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_airlines/password" >Airlines Password</a>
					</li>
				</ul>
			</li>
			<?php echo ($uri2=='setting_user_page' ? '<li id="grp_4" class="selected">' : '<li id="grp_4">');?>
				<span >Hotel
					<div class="nextrow">&nbsp;</div>
				</span>
				<ul class="sub1 sortleftmenu" id="ul_394" >
					<li id="grp_423">
						<a href="<?php echo base_url();?>index.php/admin/assets_hotel/hotel_list" >Daftar Hotel</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_hotel/hotel_supplier" >Hotel Supplier</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_hotel/hotel_price" >Hotel Price</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_hotel/hotel_coordinate" >Hotel Coordinate</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_hotel/hotel_tipe" >Tipe Hotel</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_hotel/hotel_room" >Room Type</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_hotel/hotel_facility" >Hotel Facility</a>
					</li>
				</ul>
			</li>
			<?php echo ($uri2=='setting_commission_page' ? '<li id="grp_12" class="selected">' : '<li id="grp_12">');?>
				<span >Tour
					<div class="nextrow">&nbsp;</div>
				</span>
				<ul class="sub1 sortleftmenu" id="ul_394" >
					<li id="grp_423">
						<a href="<?php echo base_url();?>index.php/admin/assets_tour/agent" >Tour Agent</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_tour/list" >Tour List</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_tour/price_custom" >Tour Price Custom</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_tour/price_default" >Tour Price Default</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_tour/category" >Tour Category</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_tour/duration" >Tour Duration</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_tour/location" >Tour Location</a>
					</li>
				</ul>
			</li>
			<?php echo ($uri2=='setting_city_page' ? '<li id="grp_401" class="selected">' : '<li id="grp_401">');?>
				<span >Travel
					<div class="nextrow">&nbsp;</div>
				</span>
				<ul class="sub1 sortleftmenu" id="ul_394" >
					<li id="grp_423">
						<a href="<?php echo base_url();?>index.php/admin/assets_travel/agent" >Travel Agent</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_travel/trayek" >Travel Trayek</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_travel/jemput" >Travel Titik Jemput</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_travel/mobil" >Travel Mobil</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_travel/price" >Travel Price</a>
					</li>
				</ul>
			</li>
			<?php echo ($uri2=='setting_agent_news_page' ? '<li id="grp_426" class="selected">' : '<li id="grp_426">');?>
				<span >Umroh/Haji
					<div class="nextrow">&nbsp;</div>
				</span>
				<ul class="sub1 sortleftmenu" id="ul_394" >
					<li id="grp_423">
						<a href="<?php echo base_url();?>index.php/admin/assets_umroh/agent" >Agent</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_umroh/list" >List</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_umroh/price_default" >Price Default</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_umroh/price_custom" >Price Custom</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_umroh/category" >Category</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_umroh/duration" >Duration</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_umroh/location" >Location</a>
					</li>
				</ul>
			</li>
			<?php echo ($uri2=='setting_agent_news_page' ? '<li id="grp_426" class="selected">' : '<li id="grp_426">');?>
				<span >Rental
					<div class="nextrow">&nbsp;</div>
				</span>
				<ul class="sub1 sortleftmenu" id="ul_394" >
					<li id="grp_423">
						<a href="<?php echo base_url();?>index.php/admin/assets_rental/agent" >Rental Agent</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_rental/vehicle" >Rental Vehicle</a>
					</li>
					<li id="grp_424">
						<a href="<?php echo base_url();?>index.php/admin/assets_rental/list" >Rental List</a>
					</li>
				</ul>
			</li>
			<?php echo ($uri2=='setting_yahoo_page' ? '<li id="grp_426" class="selected">' : '<li id="grp_426">');?>
				<a href="<?php echo base_url();?>index.php/admin/assets_point_reward" >Point Reward</a>
			</li>
			
		</ul>
	</div>
</div>