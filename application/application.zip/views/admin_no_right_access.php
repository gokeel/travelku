<!--slidemenu--> 

<div class="navigator">
	<div class="pagetitle">HOME</div>
	<div style="float:right; padding5px; color:#888; margin:5px;">Your IP: <?php echo $ip_address;?></div>
</div>

<div id="content"  style="min-height:400px;"> 

  <div class="frametab">
		<h3 style="margin:5px 0 5px 5px;">Dashboard</h3>
		<div id="no-right-access">
			<h2>Anda tidak memilik hak akses di halaman ini.</h2>
		</div>
	</div>
	<div id="end"></div>
  <!--&content--> 

</div>
