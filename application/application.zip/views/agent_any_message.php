<section role="main" id="main"><!--tpl:web/dasboard-->
<!-- Main content -->
	<noscript class="message black-gradient simpler">
		Your browser does not support JavaScript! Some features won't work as expected...
	</noscript>
	<hgroup id="main-title" class="thin">
		<h1 style="color:white">Form Top-Up</h1>
	</hgroup>
		<div class="with-padding">
			<div class="twelve-columns twelve-columns-tablet twelve-columns-mobile">
				<h3 class="thin underline">Pesan <?php echo $title;?></h3>
				<p><?php print_r($message);?></p>
			</div>
		</div>
</section>
