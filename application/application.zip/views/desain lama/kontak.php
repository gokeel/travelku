<style type="text/css">
<!--
.style1 {
	color: #FF9900;
	font-weight: bold;
	font-size:18px;
}
-->
</style>
<div class="main fullwidth">
<!-- IIRRRRFFFFAAANNN -->

                        <div class="page-title">
                        <div class="container">
                            <div style="float:left; margin-right:10px;">
                                <img src="<?php echo IMAGES_DIR;?>/kantor.jpg" alt="Page Title" width="150"/>
                            </div>
                            <div class="page-title-content">
                                <h1>Kontak kami</h1>
                                <p class="page-description">
									Terimakasih telah mengunjungi web bebasterbang.com Anda dapat menghubungi kami melalui email, sms, phone, atau menggunakan form kontak yang tersedia dibawah ini. Anda juga dapat langsung mengunjungi kantor kami yang berlokasi
                                    seperti yang tertera didalam peta berikut.
								</p>
                            </div>
                        </div>
                    </div>
                </div> <!-- Close Header Menu -->
            </div> <!-- Close Header Wrapper -->
        <div class="page-top-stripes"></div> <!-- Page Background Stripes -->

        <div class="page"> <!-- Page -->
            <div class="breadscrumbs" style="background:#F60">
                <div class="container">
                    <ul class="clearfix">
                        <li><a href="#">Home</a>/</li>
                        <li><a href="#">Kontak</a></li>
                    </ul>
                </div>
            </div>
            <div class="main contactpage">
                    
         <!-- GOOOOGLE -->           
                    
                  <div id="map_canvas"> 
          <!-- css3 preLoading-->
          <div> <iframe src="https://mapsengine.google.com/map/embed?mid=z1kUvIEBikrM.k36wVXryncQg" width="990" height="390"></iframe> </div>
        </div>
        <!-- GOOOOGLE -->
                
                <div class="container">
                    <div class="row-fluid">
                        <section class="content span9">
                            <div class="shortcode-contact-form row-fluid">
                                <form action="#" method="post" id="contactform" class="form">
                                    <div class="span4">
                                        <p class="input-wrap">
                                            <input class="comment_input comment_name" type="text" name="author" id="author" value="Your Name" size="22" tabindex="1" 
                                            onfocus="if(this.value=='Your Name')this.value='';" onBlur="if(this.value=='')this.value='Your Name';" />
                                            <i class="icon-user"></i>
                                        </p>
                                        <p class="input-wrap">
                                            <input class="comment_input comment_email" type="text" name="email" id="email" value="Your Mail" size="22" tabindex="2" 
                                            onfocus="if(this.value=='Your Mail')this.value='';" onBlur="if(this.value=='')this.value='Your Mail';"  />
                                            <i class="icon-envelope-alt"></i>
                                        </p>
                                        <p class="input-wrap">
                                            <input class="comment_input comment_website" type="text" name="url" id="url" value="Your Website" size="22" tabindex="3" 
                                            onfocus="if(this.value=='Your Website')this.value='';" onBlur="if(this.value=='')this.value='Your Website';"  />
                                            <i class="icon-external-link"></i>
                                        </p>
                                    </div>
                                    <div class="span8">
                                        <p>
                                            <textarea class="comment_textarea" name="comment" id="comment" cols="50" rows="10" tabindex="4" 
                                            onfocus="if(this.value=='Message')this.value='';" onBlur="if(this.value=='')this.value='Message';" >Message</textarea>
                                        </p>
                                    </div>
                                    <p>
                                        <input class="button" name="submit" type="submit" id="submit" tabindex="5" value="Send Message" />       
                                    </p>
                                </form>

                                <div class="contact-form-respons">
                                    <div class="infobox info-succes info-succes-alt clearfix">
                                        <span></span>
                                        <div class="infobox-wrap">
                                            <h4>Your message was succesfully send!</h4>
                                            <p>We will contact you as soon as possible. Please reload the page if you want to send a message again.</p>                                            
                                        </div>
                                        <a href="#" class="info-hide"></a>
                                    </div>
                                </div>
                            </div>
                        </section> <!-- End Content -->
                        <aside class="sidebar widgets-light span3">
                            <!-- Contact info Widget -->
                            <div class="widget-box widget-contact-info">
                                <div class="content-title">
                                    <h4 class="widget-title">Contact Information</h4>
                                </div>
                                <p class="widget-sub-title">HELLOTRAVELER.COM</p>
                                <ul>
                                    <li class="contact-info-address"><i class="icon-home"></i>Jl. Raden Inten II No. 60, Jakarta</li>
                                    <li class="contact-info-email"><i class="icon-envelope"></i><a href="#">info@hellotraveler.co.id</a></li>
                                    <li class="contact-info-phone"><i class="icon-phone"></i>+62 (21) 56789</li>
                                </ul>
                            </div>
                            <!-- Social Media Widget -->
                                       
                        </aside>
                    </div>
                </div>
            </div> <!-- Close Main -->
            <footer> <!-- Footer -->
      <!-- <div class="page-out clearfix">
        <div class="container">
          <div class="row-fluid">
            <div class="footer-logo span3"> <img src="img/footer-verendus-logo.png" alt="Verendus" /> </div>
            <div class="top-off-page span1 offset8"> <a href="#"><i class="icon-arrow-up"></i></a> </div>
          </div>
        </div>
      </div>
      <div class="footer-widgets"> <!-- Footer Widgets Area --> -->
        <div class="container">
          <div class="row-fluid">
<!-- FOOTER WIDGET -- <div class="widget-box widget-text span3" style="color:#aaa;">
              <h4 class="widget-title">Tentang Kami</h4>
              <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. exerci tation ullamcorper. </p>
              <p> Bebasterbang.com is also working with different size layouts. This also makes the website look solid on a bigger screen. </p>
              <p> Hubungi kami: <br/>Kantor Pusat: Jl. Pelemsewu 88 Yogyakarta<br/>Phone:081234567890<br/>Email:Info[at]bebasterbang.com </p>
              <p> <a href="#" style="color:#F90">Form Kontak kami</a> </p>
            </div> -->
            
            <!-- Flickr Widget -->
            
            
         <!--   <div class="widget-box widget-flickr span3">
              <h4 class="widget-title">My Flickr Stream</h4>
              <div class="flickr-wrap clearfix"> 
                <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=9&amp;display=random&amp;size=s&amp;layout=x&amp;source=user&amp;user=91197534@N02">
                                    </script> 
              </div>
            </div>
            
            -->
            
            <!-- Twitter Widget -->
            <!-- <div class="widget-box widget-twitter span3">
              <h4 class="widget-title">Twitter Feed</h4>
              <div id="twitter_update"> 
                <script type='text/javascript'>
                                      jQuery(function($){
                                        $("#query_1").tweet({
                                            join_text: "auto",
                                            username: "bebasterbang",
                                            avatar_size: 32,
                                            count: 3,
                                            auto_join_text_default: "",
                                            auto_join_text_ed: "",
                                            auto_join_text_ing: "",
                                            auto_join_text_reply: "",
                                            auto_join_text_url: "",
                                            loading_text: "loading tweets...",
                                            template: "{avatar} {text} {time}"
                                        });
                                      });
                                    </script>
                <div id="query_1" class='query'></div>
              </div>
            </div> -->
            
            <!-- Social Media Widget -->
            <!-- <div class="widget-box widget-social-media social-light span3">
              <h4 class="widget-title">Social Media</h4>
              <ul class="clearfix">
                <li class="social-icons-facebook-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-pinterest-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-linkedin-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-github-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-googleplus-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-flickr-icon"> <a href="#"></a>
                  <div></div>
                </li>

                <li class="social-icons-digg-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-skype-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-youtube-icon" > <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-forrst-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-vimeo-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-dribbble-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-stumbleupon-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-tumblr-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-wordpress-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-rss-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-twitter-icon"> <a href="#"></a>
                  <div></div>
                </li>
              </ul>
            </div>
          </div> -->
          <!-- Simpel Divider Widget
          <div class="widget-divider"><span></span></div> -->
          
         
        </div>
      </div>
      <!-- Close Footer Widgets Area -->


<!-- IIRRRRFFFFAAANNN -->
</div>