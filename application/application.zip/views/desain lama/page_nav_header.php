	<div class="header-wrap">
	  <div class="page-title">
			<div class="container">
			  <div class="page-title-avatar">  </div>
			  <div class="page-title-content">
				<h1><?php echo $title;?></h1>
				<p class="page-description"><?php echo $sub_title;?></p>
			  </div>
			</div>
		  </div>
	</div>
</div> <!-- Close header_background --> 
    <!-- Close Header Menu --> 
  
  <!-- Close Header Wrapper -->
  <div class="page-top-stripes"></div>
  <!-- Page Background Stripes -->
  
  <div class="page"> <!-- Page -->
    <div class="breadscrumbs"  style="background:#F60">
      <div class="container">
        <ul class="clearfix">
          <li><a href="<?php echo base_url();?>">Home</a>/</li>
          <li><a href="#"><?php echo $title;?></a></li>
        </ul>
      </div>
    </div>