				<!-- FOOTER1 start -->
				<div id="footer<?php echo $footer_column;?>">Mitra maskapai dan kereta api :<br />
					<img src="<?php echo IMAGES_DIR;?>/maskapai.jpg" />
				</div>
				<!-- FOOTER1 end -->
				 
				<!-- FOOTER2 start -->
				<div id="footer<?php echo $footer_column;?>">
					<div id="footer2"> Member Organisasi :<br />
						<img src="<?php echo IMAGES_DIR;?>/organisasi.jpg" />
					</div>
					<div id="footer2"> Payment system :<br />
						<img src="<?php echo IMAGES_DIR;?>/payment.jpg" />
					</div>
				</div>
				 <!-- FOOTER2 end -->
				 
				 <!-- FOOTER ORANGE start -->
				<div id="footerorange<?php echo $footer_column;?>">
					<div id="logofooter">
						<img src="<?php echo IMAGES_DIR;?>/footer.jpg" />
					</div>
					<div id="footertext">
						Tentang Kami<br />
						Tentang Keagenan<br />
						<a href="<?php echo base_url();?>index.php/webfront/payment_method">Metode Pembayaran</a><br />
						<a href="<?php echo base_url();?>index.php/webfront/confirm_payment">Konfirmasi Pembayaran Paket</a><br />
						<a href="<?php echo base_url();?>index.php/webfront/confirm_payment_tiketcom">Konfirmasi Pembayaran Tiket</a><br />
						<a href="<?php echo base_url();?>index.php/webfront/cancel_order_tiketcom">Pembatalan Tiket</a><br />
					</div>
					<div id="footertext">
						Testimoni<br />
						Karir<br />
						Syarat & Ketentuan<br />
						Manual book sistem<br />
						<br />
					</div>
					<div id="callcenter">
					</div>
					<div id="footertext">
						Alamat :<br />
						Jl. Raden Inten No. 60<br />
						Jakarta<br />
						+62-21-86603475<br />
						info@hellotraveler.co.id<br />
					</div>
				</div>
				<!-- FOOTER ORANGE end -->
				  
				  
			</div><!-- div konten end -->                                
		</div> <!-- bodytengah end -->
	<!--</div> wrapper end -->
		  <!-- <div id="header"> -->
	<!--</div> -->
		<!-- div id="body" -->

</body>
</html>