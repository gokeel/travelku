			<div id="content">
				<div id="kolom1">
					<div id="pakettour">
					<!-- HEADER PAKET mulai -->
						<div id="headerpaket">
							<div id="headerpaket-ki"></div>
							<div id="headerpaket-tgh">Paket <span class="headerpakettext">TOUR SPECIAL</span></div>
							<div id="headerpaket-ka"></div>
							<div id="headerpaketgaris"></div>
						</div>
					<!-- HEADER PAKET end -->
						<!-- KONTEN PAKET mulai -->
						
						
					</div>
					<!-- PROMO PESAWAT mulai -->
					<div id="promopesawat">
						<!-- HEADER promo mulai -->
						<div id="headerpaket">
							<div id="headerpaket-ki"></div>
							<div id="headerpaket-tgh">PROMO <span class="headerpakettext">PESAWAT MINGGU INI</span></div>
							<div id="headerpaket-ka"></div>
							<div id="headerpaketgaris"></div>
						</div>
						<!-- HEADER promo end -->
						<div id="promopesawat2">
							<div id="promopesawatisi">
								<!--<div id="promokolom">
									<div class="pad"> 
										<strong>Dari Jakarta</strong><br>
										<ul class="pad_bot1 list1">
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Surabaya</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Makassar</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Padang</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Batam</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Yogyakarta</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Semarang</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Medan</a> </li>
										</ul>
										<strong>Dari Surabaya</strong><br>
										<ul class="pad_bot1 list1">
											<li> <span class="right color1">mulai IDR. 430.000,-</span> <a href="book2.html">ke Jakarta</a> </li>
											<li> <span class="right color1">mulai IDR. 650.000,-</span> <a href="book2.html">ke Medan</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Makassar</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Manado</a> </li>
										</ul>
									</div>
								</div>
								<div id="promokolom">
									<div class="pad"> <strong>Dari Medan</strong><br>
										<ul class="pad_bot1 list1">
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Surabaya</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Makassar</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Padang</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Batam</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Yogyakarta</a> </li>
										</ul>
										<strong>Dari Batam</strong><br>
										<ul class="pad_bot1 list1">
											<li> <span class="right color1">mulai IDR. 430.000,-</span> <a href="book2.html">ke Jakarta</a> </li>
											<li> <span class="right color1">mulai IDR. 650.000,-</span> <a href="book2.html">ke Medan</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke yogyakarta</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Balikpapan</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Banda Aceh</a> </li>
											<li> <span class="right color1">mulai IDR. 350.000,-</span> <a href="book2.html">ke Jambi</a> </li>
										</ul>
									</div>
								</div>-->
							</div>
						</div>
					</div>
					<!-- PROMO PESAWAT end -->
					
					<div id="mengapaharus">
						<div id="headermengapa">
							<div id="headermengapa-ki"></div>
							<div id="headermengapa-tgh">MENGAPA HARUS DENGAN<span class="headermengapatext"> HELLO TRAVELER</span></div>
							<div id="headermengapa-ka"></div>
						</div>
						<div id="mengapa">
							<div id="mengapaisi">
								<div class="container-510">
									<!--<span class="container-header-blue container-header-radius5">WHY YUKTRAVEL</span>-->
									<div id="whyyuktravel" class="container-background-blue">
										<div class="container-border-blue">
											<span class="title">LAYANAN PALING LENGKAP</span>
											<ul>
												<li>Hotel Booking dengan <strong>3.000+ hotel di Indonesia</strong> dan <strong>200.000+ hotel di luar negeri</strong> dengan fitur konfirmasi instan</li>
												<li>Pesan Tiket Pesawat Domestik dan Luar Negeri dengan pilihan maskapai paling lengkap</li>
												<li><strong>Ratusan paket tour</strong> &amp; perjalanan <strong>Kapal Pesiar</strong> baik untuk tour individu ataupun group</li>
											</ul>
											<span class="title">AMAN, TERPERCAYA &amp; PERSONAL</span>
											<ul>
												<li><strong>Aman</strong>, cara pembayaran online dengan aman menggunakan kartu kredit, klikBCA, ataupun bank transfer</li>
												<li><strong>Terpercaya</strong>, Hellotraveler adalah biro perjalanan wisata (BPW) berlisensi IATA dan ASITA</li>
												<li><strong>Personal</strong>, layanan personal dan profesional oleh konsultan travel kami di:<strong>Jakarta (021-6531 4171), Bandung (022-8446 0036), </strong></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

<script>
	$( window ).load(function() {
		load_post_pakettour();
		load_post_pesawat();
		
	});
	function load_post_pesawat(){
		var data = [];
		$.ajax({
			type : "GET",
			async: false,
			url: '<?php echo base_url();?>index.php/webfront/get_post_by_category/pesawat/0/20',
			dataType: "json",
			success:function(datajson){
				var div = $('#promopesawatisi');
				var str = '<div id="promokolom"><div class="pad"><ul class="pad_bot1 list1">';
				for(var i=0; i<datajson.length;i++){
					if(i==10){
						str = str + '</ul></div></div>';
						div.append(str);
						str='<div id="promokolom"><div class="pad"><ul class="pad_bot1 list1">';
					}
						
					str = str + '<li> <span class="right color1">IDR '+currency_separator(datajson[i].price, '.')+'</span> <a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'">'+datajson[i].title+'</a> </li>';
				}
				str = str + '</ul></div></div>';
				div.append(str);
			}
		});
	}
	
	function load_post_pakettour(){
		var data = [];
		$.ajax({
			type : "GET",
			async: false,
			url: '<?php echo base_url();?>index.php/webfront/get_post_by_category/tour-umrah-travel/0/12',
			dataType: "json",
			success:function(datajson){
				var div = $('#pakettour');
				var str = '';
				for(var i=0; i<datajson.length;i++){
					if(i==0 || i==4 || i==8)
						str = str + '<div id="konten_paket">';
					if(i>=0 && i<3){
						str = str+	'<div id="paket">\
										<div id="headerhijau-ki"></div>\
										<div id="headerhijau">\
											<span class="headerhijautext">'+toUpperCase(datajson[i].category)+'</span>\
										</div>\
										<div id="headerhijaugaris"></div>\
										<div id="gambarpaket"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'""><img src="<?php echo base_url();?>assets/uploads/posts/'+datajson[i].image_file+'"  width="133px" height="101px"/></a></div>\
										<div id="abu-abu"><span class="namapakettext"><strong>'+datajson[i].title+'</strong></span></div>\
										<div id="hargapaket">\
											<div id="readmore"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'" style="text-decoration:none"><span class="readmoretext">read more</span></a></div>\
											<div id="pembatas"><img src="<?php echo IMAGES_DIR;?>/pembatas.jpg" /></div>\
											<div id="harga"><span class="mulaiidr">Mulai IDR</span><br />\
												<span class="hargatext">'+currency_separator(datajson[i].price, '.')+'</span></div>\
										</div>\
									</div>';
						
					}
					if(i==3){
						str = str+	'<div id="paket">\
										<div id="headerhijau-ki"></div>\
										<div id="headerhijau">\
											<span class="headerhijautext">'+toUpperCase(datajson[i].category)+'</span>\
										</div>\
										<div id="headerhijaugaris"></div>\
										<div id="gambarpaket"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'""><img src="<?php echo base_url();?>assets/uploads/posts/'+datajson[i].image_file+'"  width="133px" height="101px"/></a></div>\
										<div id="abu-abu"><span class="namapakettext"><strong>'+datajson[i].title+'</strong></span></div>\
										<div id="hargapaket">\
											<div id="readmore"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'" style="text-decoration:none"><span class="readmoretext">read more</span></a></div>\
											<div id="pembatas"><img src="<?php echo IMAGES_DIR;?>/pembatas.jpg" /></div>\
											<div id="harga"><span class="mulaiidr">Mulai IDR</span><br />\
												<span class="hargatext">'+currency_separator(datajson[i].price, '.')+'</span></div>\
										</div>\
									</div></div>';
					}
					if(i>=4 && i<7){
						str = str+	'<div id="paket">\
										<div id="headerkuning-ki"></div>\
										<div id="headerkuning">\
											<span class="headerkuningtext">'+toUpperCase(datajson[i].category)+'</span>\
										</div>\
										<div id="headerkuninggaris"></div>\
										<div id="gambarpaket"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'""><img src="<?php echo base_url();?>assets/uploads/posts/'+datajson[i].image_file+'" width="133px" height="101px"/></a></div>\
										<div id="abu-abu"><span class="namapakettext"><strong>'+datajson[i].title+'</strong></span></div>\
										<div id="hargapaket">\
											<div id="readmore"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'" style="text-decoration:none"><span class="readmoretext">read more</span></a></div>\
											<div id="pembatas"><img src="<?php echo IMAGES_DIR;?>/pembatas.jpg" /></div>\
											<div id="harga"><span class="mulaiidr">Mulai IDR</span><br />\
												<span class="hargatext">'+currency_separator(datajson[i].price, '.')+'</span></div>\
										</div>\
									</div>';
					}
					if(i==7){
						str = str+	'<div id="paket">\
										<div id="headerkuning-ki"></div>\
										<div id="headerkuning">\
											<span class="headerkuningtext">'+toUpperCase(datajson[i].category)+'</span>\
										</div>\
										<div id="headerkuninggaris"></div>\
										<div id="gambarpaket"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'""><img src="<?php echo base_url();?>assets/uploads/posts/'+datajson[i].image_file+'" width="133px" height="101px"/></a></div>\
										<div id="abu-abu"><span class="namapakettext"><strong>'+datajson[i].title+'</strong></span></div>\
										<div id="hargapaket">\
											<div id="readmore"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'" style="text-decoration:none"><span class="readmoretext">read more</span></a></div>\
											<div id="pembatas"><img src="<?php echo IMAGES_DIR;?>/pembatas.jpg" /></div>\
											<div id="harga"><span class="mulaiidr">Mulai IDR</span><br />\
												<span class="hargatext">'+currency_separator(datajson[i].price, '.')+'</span></div>\
										</div>\
									</div></div>';
					}
					if(i>=8 && i<11){
						str = str+	'<div id="paket">\
										<div id="headerbiru-ki"></div>\
										<div id="headerbiru">\
											<span class="headerbirutext">'+toUpperCase(datajson[i].category)+'</span>\
										</div>\
										<div id="headerbirugaris"></div>\
										<div id="gambarpaket"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'""><img src="<?php echo base_url();?>assets/uploads/posts/'+datajson[i].image_file+'" width="133px" height="101px"/></a></div>\
										<div id="abu-abu"><span class="namapakettext"><strong>'+datajson[i].title+'</strong></span></div>\
										<div id="hargapaket">\
											<div id="readmore"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'" style="text-decoration:none"><span class="readmoretext">read more</span></a></div>\
											<div id="pembatas"><img src="<?php echo IMAGES_DIR;?>/pembatas.jpg" /></div>\
											<div id="harga"><span class="mulaiidr">Mulai IDR</span><br />\
												<span class="hargatext">'+currency_separator(datajson[i].price, '.')+'</span></div>\
										</div>\
									</div>';
					}
					if(i==11){
						str = str+	'<div id="paket">\
										<div id="headerbiru-ki"></div>\
										<div id="headerbiru">\
											<span class="headerbirutext">'+toUpperCase(datajson[i].category)+'</span>\
										</div>\
										<div id="headerbirugaris"></div>\
										<div id="gambarpaket"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'""><img src="<?php echo base_url();?>assets/uploads/posts/'+datajson[i].image_file+'" width="133px" height="101px"/></a></div>\
										<div id="abu-abu"><span class="namapakettext"><strong>'+datajson[i].title+'</strong></span></div>\
										<div id="hargapaket">\
											<div id="readmore"><a href="<?php echo base_url();?>index.php/webfront/show_post/'+datajson[i].id+'" style="text-decoration:none"><span class="readmoretext">read more</span></a></div>\
											<div id="pembatas"><img src="<?php echo IMAGES_DIR;?>/pembatas.jpg" /></div>\
											<div id="harga"><span class="mulaiidr">Mulai IDR</span><br />\
												<span class="hargatext">'+currency_separator(datajson[i].price, '.')+'</span></div>\
										</div>\
									</div></div>';
					}
				}
				div.append(str);
			}
		});
	}
</script>

								
									
									