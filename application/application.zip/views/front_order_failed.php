			<div id="content">
			<!-- KONTEN MULAI -->
				<div id="kolom1-second-faq">
					<div id="kontenkolom1">
					<!-- KOLOM 1 mulai --> 
						<div id="faqkonten">
							<p align="justify"><span class="judul46">Order Gagal</span><br /><br /><br /></p>
							<p align="justify"><span class="judul18">Mohon periksa kembali masukan anda, atau hubungi Live Support kami.</span><br /><br /><br /></p>
						</div>
					</div>
				<!-- KONTEN end -->
				</div>
			</div>