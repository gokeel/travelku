				<!-- KOLOM 2 mulai -->
				<div id="column2-minimals">
					<div id="tentang">
						<!-- HEADER tentang mulai -->
						<div id="headertentang">
							<div id="headerpaket-ki"></div>
							<div id="headertentang-tgh">Selamat datang di <span class="headerpakettext">HELLOTRAVELER</span></div>
							<div id="headerpaket-ka"></div>
							<div id="headertentanggaris-second"></div>
						</div>
						<!-- HEADER tentang end -->
						<div id="tentangisi">Hello traveler adalah travel operator yang memberikan berbagai pilihan dan solusi perjalanan anda. Baik perjalanan domestik maupun 	internasional. Selain paket-paket yang telah kami sediakan, tim Hello traveler siap memberikan konsultasi dan solusi paket-paket perjalanan yang belum ada.<br />
		Hello traveler juga memberikan pelayanan terbaik dalam pemesanan tiket penerbangan dan kereta api.<br /><br />
		Dengan berbagai kemudahan yang kami berikan, Selamat menikmati perjalanan anda, biarkan kami yang mengurus "semuanya"...
						</div>
						<div id="banner1"> <img src="<?php echo IMAGES_DIR;?>/banner-umroh.jpg" width="350px" /> </div>
						<div id="banner1" style="margin-top:15px"> <img src="<?php echo IMAGES_DIR;?>/banner-f1.jpg" width="350px" /> </div>
						<div id="banner1" style="margin-top:15px"> <img src="<?php echo IMAGES_DIR;?>/banner-motogp.jpg" width="350px" /> </div>
						
					   
						
						
					</div>
				</div>
				<!-- KOLOM 2 end -->
				