				<!-- RUNNING TEXT start -->
				<div id="runningtext">
					<div style="background-color:#f59e00; width:30px; height:36px; float:left"></div>
					<div style="padding-left:20px; padding-top:10px; float:left"><strong>HOT PROMO :</strong></div>
					<!--<div style="padding-left:20px; padding-top:10px;" > <marquee direction="right" scrollamount="2"> # ini adalah running text  # Umroh 4 orang hanya IDR 14.000.000,-/pax  #Tour HONGKONG 4 orang hanya IDR 5.000.000,-/pax  # ini adalah running text </marquee></div>-->
				</div>
				<!-- RUNNING TEXT end --> 
				