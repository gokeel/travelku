<footer> <!-- Footer -->
      <div class="page-out clearfix">
        <div class="container">
          <div class="row-fluid">
            <div class="footer-logo span3"> <img src="<?php echo IMG_DIR;?>/footer-verendus-logo.png" alt="Verendus" /> </div>
            <div class="top-off-page span1 offset8"> <a href="#"><i class="icon-arrow-up"></i></a> </div>
          </div>
        </div>
      </div>
      <div class="footer-widgets"> <!-- Footer Widgets Area -->
        <div class="container">
          <div class="row-fluid">
			<div class="widget-box widget-text span3" style="color:#aaa;">
				<h4 class="widget-title">Tentang Kami</h4>
				<p><a href="#">Profil Kami</a></p>
				<p><a href="#">FAQ</a></p>
				<p><a href="#">Berita</a></p>
			</div>
			<div class="widget-box widget-text span3" style="color:#aaa;">
				<h4 class="widget-title">Produk</h4>
				<p><a href="<?php echo base_url();?>index.php/flight/page">Pesawat</a></p>
				<p><a href="<?php echo base_url();?>index.php/train/page">Kereta Api</a></p>
				<p><a href="<?php echo base_url();?>index.php/hotel/page">Hotel</a></p>
				<!--<p><a href="#">Tour</a></p>
				<p><a href="#">Travel</a></p>-->
			</div>
			<div class="widget-box widget-text span3" style="color:#aaa;">
				<h4 class="widget-title">Layanan</h4>
				<p><a href="<?php echo base_url();?>index.php/order/confirm_payment">Konfirmasi Pembayaran</a></p>
				
			</div>
            <!--<div class="widget-box widget-text span3" style="color:#aaa;">
              <h4 class="widget-title">Tentang Kami</h4>
              <p> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. exerci tation ullamcorper. </p>
              <p> Bebasterbang.com is also working with different size layouts. This also makes the website look solid on a bigger screen. </p>
              <p> Hubungi kami: <br/>Kantor Pusat: Jl. Pelemsewu 88 Yogyakarta<br/>Phone:081234567890<br/>Email:Info[at]bebasterbang.com </p>
              <p> <a href="#" style="color:#F90">Form Kontak kami</a> </p>
            </div>
			-->
            <!-- Flickr Widget -->
            <!--<div class="widget-box widget-flickr span3">
              <h4 class="widget-title">My Flickr Stream</h4>
              <div class="flickr-wrap clearfix"> 
                <script type="text/javascript" src="http://www.flickr.com/badge_code_v2.gne?count=9&amp;display=random&amp;size=s&amp;layout=x&amp;source=user&amp;user=91197534@N02">
                                    </script> 
              </div>
            </div>
            -->
            <!-- Twitter Widget -->
            <!--<div class="widget-box widget-twitter span3">
              <h4 class="widget-title">Twitter Feed</h4>
              <div id="twitter_update"> 
                <script type='text/javascript'>
                                      jQuery(function($){
                                        $("#query_1").tweet({
                                            join_text: "auto",
                                            username: "bebasterbang",
                                            avatar_size: 32,
                                            count: 3,
                                            auto_join_text_default: "",
                                            auto_join_text_ed: "",
                                            auto_join_text_ing: "",
                                            auto_join_text_reply: "",
                                            auto_join_text_url: "",
                                            loading_text: "loading tweets...",
                                            template: "{avatar} {text} {time}"
                                        });
                                      });
                                    </script>
                <div id="query_1" class='query'></div>
              </div>
            </div>
            -->
            <!-- Social Media Widget -->
            <!--<div class="widget-box widget-social-media social-light span3">
              <h4 class="widget-title">Social Media</h4>
              <ul class="clearfix">
                <li class="social-icons-facebook-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-pinterest-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-linkedin-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-github-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-googleplus-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-flickr-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-digg-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-skype-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-youtube-icon" > <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-forrst-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-vimeo-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-dribbble-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-stumbleupon-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-tumblr-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-wordpress-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-rss-icon"> <a href="#"></a>
                  <div></div>
                </li>
                <li class="social-icons-twitter-icon"> <a href="#"></a>
                  <div></div>
                </li>
              </ul>
            </div> -->
          </div>
          <!-- Simpel Divider Widget
          <div class="widget-divider"><span></span></div> -->
        </div>
      </div>
      <!-- Close Footer Widgets Area -->
      <div class="footer-meta"> <!-- Footer meta -->
        <div class="container">
          <div class="row-fluid">
            <div class="sitemap-holder span7">
              <ul class="sitemap-menu clearfix">
                <li> <a href="<?php echo base_url();?>">Home</a> </li>
                <li> <a href="#">Hotel</a> </li>
                <li> <a href="#">Paket Wisata</a> </li>
                <li> <a href="#">Berita</a> </li>
                <li> <a href="#">Kontak</a> </li>
              </ul>
            </div>
            <div class="copyright span4 offset1">
              <p>� Copyright 2012 - <a href="#">bebasterbang.com</a> by <a href="#">hellotraveler</a></p>
            </div>
          </div>
        </div>
      </div>
      <!-- Close Footer meta --> 
    </footer>
    <!-- Close Footer --> 
  </div>
  <!-- Close Page --> 
</div>
<!-- Close wrapper --> 

<!-- Load all Javascript Files --> 
<script src="<?php echo JS_DIR;?>/vendor/bootstrap.min.js"></script> 
<script src="<?php echo JS_DIR;?>/jquery.hoverdir.js"></script> 
<script src="<?php echo JS_DIR;?>/superfish.js"></script> 
<script src="<?php echo JS_DIR;?>/supersubs.js"></script> 
<script src="<?php echo JS_DIR;?>/jquery.tweet.js"></script> 
<script src="<?php echo JS_DIR;?>/jquery.flexslider.js"></script> 
<script src="<?php echo JS_DIR;?>/retina.js"></script> 
<script src="<?php echo JS_DIR;?>/jquery.jcarousel.min.js"></script> 
<script src="<?php echo JS_DIR;?>/custom.js"></script>
</body>
</html>