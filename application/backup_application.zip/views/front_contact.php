			<div id="content">
				<!-- KONTEN MULAI -->
				<div id="kolom1-second-contact">
					<div id="kontenkolom1">
						<!-- KOLOM 1 mulai --> 
						<div id="contactkonten">
							<div align="justify"> <span class="judul46">Contact</span><br /><br /><br />
								<p align="justify"><span class="judul18">Alamat</span><br />
								Jl. Raden Inten No. 60<br />
								Jakarta<br />
								+62 (21) 86603475<br />
								info@hellotraveler.co.id</p>

								<p style="margin-top:15px; margin-bottom:15px">Petugas kami melayani 24 jam/7 hari ats berbagai informasi yang dibutuhkan oleh pelanggan dan calon pelanggan. Hal tersebut amat dibutuhkan, mengingan kebutuhan terhadap akomodasi dan perjalanan tanpa mengenal batas waktu. kami persilakan anda untuk menghubungi kami kapanpun</p>
								<article>
									<h3 class="pad_top1">Contact Form</h3>
									<form id="ContactForm" action="#">
										<div>
											<div  class="wrapper"> <span>Name:</span>
												<input type="text" class="input" >
											</div>
											<div  class="wrapper"> <span>Email:</span>
												<input type="text" class="input" >
											</div>
											<div  class="textarea_box"> <span>Message:</span>
												<textarea name="textarea" cols="1" rows="1"></textarea>
											</div>
											<a href="#" class="button1"><strong>Send</strong></a> <a href="#" class="button1"><strong>Clear</strong></a> 
										</div>
									</form>
								</article>
							</div>
						</div>
					<!-- KONTEN end -->
					</div>
				</div>