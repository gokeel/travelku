			<div id="content">
				<!-- KONTEN MULAI -->
				<div id="kolom1-second-faq">
					<div id="kontenkolom1">
						
						<!-- KOLOM 1 mulai --> 
						<div id="faqkonten">
							<div align="justify"> 
								<p align="justify"><span class="judul46">Frequently Ask and Question</span><br /><br /><br />
								<span class="judul18">1. Siapa Hello Traveler Indonesia sebenarnya ?</span><br />
							 
								jawab: Hello Traveler Indonesia  Sebuah Sistem Pendukung usaha Travel Agent yang di rancang secara Instant yang dioperasi kan menggunakan Sistem pemesanan dengan Konsep One Stop Travel Service yang artinya hanya dengan 1 Klik anda bisa mendapatkan semua Product Perjalanan. Saat ini hanya kami yang mengembangkan Bisnis Kemitra yang mengerti Kebutuhan Mitra, sebab Kami seperti Anda sebelumnya</p>
							 
								<p align="justify"><span class="judul18">2. Apa aja sih product yang dimiliki Hello traveler</span><br />
							 
								jawab: Product - product  hellotraveler.co.id  produk product yang sangat di butuhkan oleh masyarakat luas berhubungan dengan Perjalanan , Product yang kami tawarkan bervariatif antara lain :<br /><br />
							 
									<ol>
										<li><span class="judul18">Ticketing</span> <br />
										yang meliputi : LION AIR, GARUDA, TRIGANA, KALSTAR, AVIASTAR, CITILINK, AIRASIA, SRIWIJAYA AIR, MERPATI NUSANTARA, TRANSNUSA, SKY AIR, MANDALA AIR , KERETA API, dan untuk INTERNATIONAL Tiket dalam proses Integrasi</li>
										 
										<li><span class="judul18">Hotel </span><br />
										Produk Pemesanan Hotel dengan Sistem Instan confirmation dimana Anda langsung mendapatkan Konfirmasi Instan dari Hotel , didukung system GDS maka pemesanan Hotel Anda langsung terinput di system reservasi Hotel , Mudah, Cepat dan anda dapat menekan Biaya Reservasi se minim mungkin,  Saat ini kami sudah bekerja sama dengan Ribuan  hotel di seluruh indonesia,</li>
										 
										<li><span class="judul18">Paket Tour</span> <br />
										  kami adalah ground operator untuk JAWA TENGAH, JAWA TIMUR, JAWA BARAT, JAKARTA, YOGYAKARTA, DAN KOTA KOTA LAIN DI INDONESIA. Dan kami telah menjaln kemitraan dengan beberapa local agen di berbagai penjuru tanah air. Kami menyediakan bernagai jenis tour baik domistic maupun manca negara dengan harga yang sangat kompetitif, sehingga Agen Mitra tidak perlu menaikan lagi harga paket yang kami tawarkan. Para Mitra agen sudah mendapatkan komisi dari pemasaran.</li>
										 
										<li><span class="judul18">Rental</span> <br />
										Layanan Sewa Kendaraan Guna memudahkan kebutuhan akan solusi Perjalanan Wisata, hingga anda dapat lebih menikmati Suasana Wisata Anda. Solusi Transportasi yang dinikmati para wisatawan, di desain dengan Konsep pelayanan yang Khas untuk sesuai dengan Kebutuhan transportasi wisata.<br />
										Mitra Agen tidak perlu Repot Mencarikan Armada untuk Tamu tamu Anda. Anda Tinggal KLIK Kota yang anda Inginkan dan akan muncul Pilihan Kendaraan yang sesuai dengan Kebutuhan Anda.</li>
										Beragam Jenis Kendaraan tersedia dari Mulai AVANZA/ZENIA, INOVA, TRAVELLO, ELF, hingga BUS PARIWISATA dan dilengkapi dengan system management yang didukung system Teknologi Mutakhir.
										 
										<li><span class="judul18">Travel</span><br />
										Kemudahan Untuk Pemesanan Tiket Travel / shuutle Service dengan rute Rute Tertentu. Anda Tidak perlu repot untuk menanyakan kesediaan tiket untuk rute travel tertentu.
										Anda tinggal KLIK, Pilih Kursi Cetak Voucher dan Berangkat,  Saat ini tersedia berbagai Macam Layanan Shuttle antara lain DAYTRANS, CIPAGANTI, TRANS  JAYA, CITITRANS</li>
									</ol>
								</p>
							 
								<p align="justify"><span class="judul18">3. Apakah Hello traveler Indonesia Melayani Penjualan Langsung ke Konsumen ?</span><br />
								 
								jawab: TIDAK. Hello Traveler Indonesia mengusung Konsep B2B ( Bussines to Bussines ) sebagai core bisnis travel Agent. Sehingga Konsep ini hanya di peruntukan bagi member yang tergabung di Hello traveler Indonesia.</p>
								 
								<p align="justify"><span class="judul18">4. Apa Keuntungan Yang di dapat jika bergabung dengan hello Traveler Indonesia ?</span><br />
								 
								jawab: Banyak sekali keuntungan yang bisa di dapat dengan bergabung di hellotraveler Indonesia, diantaranya harga yang tentunya lebih murah dibandingkan pemesanan langsung ke maskapai penerbangan, pemesanan langsung ke Hotel dan pemesanan langsung ke Shuttle Service unrtuk informasi detai mengenai Keuntungan klik Mitra � Pembagian keuntungan</p>
							 
								<p align="justify"><span class="judul18">5. Siapa Saja Yang bisa bergabung dengan hello Traveler Indonesia ?</span><br />
								 
								jawab: Siaappaa Saja bisa bergabung di Bisnis Ini Baik itu Perorangan, ibu Rumah tangga, Perusahaan, travel Agent, Kanto, Koperas, warnet, counter Pulsa, dan terbuka bagi siapapun yang ingin memiliki Bisnis Tiketing.</p>
							 
								<p align="justify"><span class="judul18">Bagaimana cara bergabung?
									</span>
									<ol>
										<li><span class="judul18">Bagaimana sih cara menjadi member Hello Traveler Indonesia ?</span><br />
										 
										jawab: Untuk Bergabung menjadi member Anda harus registrasi di web hellotraveler.co.id terlebih dahulu</li>
										 
										<li><span class="judul18">Apa yang Perlu disiapkan untuk registrasi di hello traveler</span><br />
										 
										jawab: Anda hanya Perlu menyiapkan Scan identitas diri yang akan digunakan untuk registrasi keanggotaan. Dan selanjutnya silahkan isi form yang ada di halaman Registrasi. Untuk Lebih lengkapnya silahkan kunjungi halaman Cara pendaftaran</li>
										 
										<li><span class="judul18">Apakah Hello traveler Indonesia Melayani Penjualan Langsung ke Konsumen ?</span><br />
										 
										jawab: TIDAK! Hello Traveler Indonesia mengusung Konsep B2B ( Bussines to Bussines ) sebagai core bisnis travel Agent. Sehingga Konsep ini hanya di peruntukan bagi member yang tergabung di Hello traveler Indonesia.</li>
							 
										<li><span class="judul18">Apa Keuntungan Yang di dapat jika bergabung dengan hello Traveler Indonesia ?</span><br />
										 
										jawab: Banyak sekali keuntungan yang bisa di dapat dengan bergabung di hellotraveler Indonesia, diantaranya harga yang tentunya lebih murah dibandingkan pemesanan langsung ke maskapai penerbangan, pemesanan langsung ke Hotel dan pemesanan langsung ke Shuttle Service unrtuk informasi detai mengenai Keuntungan klik Mitra � Pembagian keuntungan</li>
										 
										<li><span class="judul18">Siapa Saja Yang bisa bergabung dengan hello Traveler Indonesia ?</span><br />
										 
										jawab: Siaappaa Saja bisa bergabung di Bisnis Ini Baik itu Perorangan, ibu Rumah tangga, Perusahaan, travel Agent, Kanto, Koperas, warnet, counter Pulsa, dan terbuka bagi siapapun yang ingin memiliki Bisnis Tiketing.</li>
										 
										<li><span class="judul18">Berapa lama informasi login Saya terima setelah saya menyelesaikan proses registrasi dan pembayaran?</span><br />
										 
										jawab: Informasi login, biasanya akan Anda terima kurang dari 5 menit dan dikirimkan ke email yang Anda daftarkan, Silahkan kunjungi E-mail yang anda daftarkan di Portal hello Traveler dan Klik E-mail Verifikasi untuk memverifikasi bahwa memang e-mail Anda lah yang benar � benar Anda daftarkan.</li>
							 
										<li><span class="judul18">Setelah Saya cek, informasi login tidak saya terima di Inbox email Saya, apa yang harus Saya lakukan?</span><br />
										 
										jawab: Kami sarankan Anda cek Inbox Spam Anda. Jika masih tidak ditemukan, mungkin Anda memasukkan informasi alamat email yang salah saat Registrasi, silakan hubungi Tim Customer Support kami melalui email (agent.hellotraveler@gmail.com) atau hotline kami di (024)5015 4181 atau melalui fitur LiveChat yang Kami sediakan</li>
							 
										<li><span class="judul18">Setelah terdaftar, bagaimana cara saya login?</span><br />
										 
										jawab: Silakan buka Halaman Login dan masukkan user name dan password yang kami email setelah Anda selesaikan proses Registrasi</li>
									</ol>
								</p>
							 
								<p align="justify"><span class="judul18">Apa yang bisa di lakukan setelah menjadi Member?
											</span>
									<ol>
								 
										<li><span class="judul18">Apa saja skema Membership yang ditawarkan Hello Traveler Indonesia ?</span><br />
										 
										jawab: Silakan lihat halaman Paket Kemitraan Kami</li>
										 
										<li><span class="judul18">Kalau Ada member Agen pasti ada member Sub Agen, Apa si bedanya Member Agen dan member Sub Agen ?</span><br />
										 
										jawab: Agen adalah perorangan atau travel agen yang mendaftarkan dengan dengan membayar sesuai yang di tentukan, dan bisa merecruit sub agen - sub agen,
										sedangkan Subagen adalah peroragan atau travel agent yang di daftarkan oleh Agen atau mendaftar langsung mendaftarkan diri sebagi sub agen. Tetapi subagen  tidak bisa mendaftarakan perorangan atau travel agent di bawahnya.</li>
										 
										<li><span class="judul18">Bagaimana cara mendaftarkan subagen saya ?</span><br />
										 
										jawab: Agen hanya mengisi form pendaftaran subagen yang terdapat di menu Agen yang terdapat dalam login keanggotaan Anda, selanjutnya Sub Agen Anda akan mendapatkan E-mail verifikasi yang harus di Klik link tersebut untuk memverifikasi pendaftaran, selanjutnya subagen anda Mentransfer Biaya Aktivasi ke Rekening kami dan Selanjutnya Sub agent Anda langsung Bisa Bertransaksi tanpa Syarat Apapun.</li>
										 
										<li><span class="judul18">Jika sudah menjadi subagen mitra apakah bisa upgrade menjadi Agen mitra ?</span><br />
										 
										jawab: Bisa. Tentunya dengan menunjukan surat pemberian kuasa dari Agen yang membawahinya. dan membayar sejumlah biaya yang sudah di tetapkan.</li>
										<li><span class="judul18">Saya sudah terdaftar sebagai Personal Agent. Saat terjadi penambahan Maskapai, apakah saya harus membayar lagi ?</span><br />
										 
										jawab: TIDAK�!!!!. Penambahan Maskapai dapat Anda nikmati tanpa perlu membayar lagi.</li>
										 
										<li><span class="judul18">Apakah setiap Member Personal Agent harus mempunyai Deposit ?</span><br />
										 
										jawab: Tidak Harus. Selain Deposit, Anda dapat melakukan transaksi melalui Transfer atau Direct Debit bahkan Kartu Kredit. Tapi kami sarankan Anda memiliki Deposit agar proses issue tiket dapat berjalan lebih cepat dan fleksibel, terutama saat menjelang pergantian hari atau hari libur</li>
										 
										<li><span class="judul18">Jika saya deposit, berapa yang harus saya depositkan dan apakah aman ?</span><br />
										 
										jawab: Jika anda deposit, Hello Traveler Indonesia tidak mematok berapa yang harus di depositkan, Untuk keamanannya kami menerapkan sampai ZERO DEPOSIT, dimana sisa deposit yang ada bisa di tambah dengan transfer selanjutnya. Misalnya deposit anda sisa Rp. 200.000, anda ada tansaksi Rp. 235.000. cukup dengan menambah 35.000 transaksi anda dapat di proses. Pada dasarnya Deposit hanya untuk mempercepat proses transaksi saja</li>
								 
										<li><span class="judul18">Apakah Saya dapat melihat catatan penggunaan Deposit Saya?</span><br />
										 
										jawab: YA TENTU SAJA. Anda dapat melihatnya di menu "Laporan Penjualan setelah Anda login".</li>
										 
										<li><span class="judul18">Jika lama saya tidak ada transaksi dan saya ingin tarik deposit saya, apakah bisa ?</span><br />
										 
										jawab: INILAH KEUNGGULAN DARI HELLO TRAVELER INDONESIA. Anda bisa menarik Deposit Anda bila Anda menginginkan penggembalian Deposit tersebut, di dalam menu Login terdapat fasilitas tarik Deposit.</li>
									</ol>
								</p>
							 
								<p align="justify"><span class="judul18">Search & Book </span>
									<ol>
										<li><span class="judul18">Bagaimana caranya mencari tiket termurah?</span><br />
										 
										jawab: Caranya sangat mudah. Pilih kota keberangkatan, kota tujuan, tanggal dan jumlah penumpang. Sistem kami akan mencarikan tiket termurah dari beberapa airline yang memiliki kriteria yang Anda masukkan.</li>
										 
										<li><span class="judul18">Airline/Maskapai apa saja yang didukung Hello Traveler Indonesia ?</span><br />
										 
										jawab: Saat ini cakupan Airline yang kami dukung antara lain AirAsia, Citylink, Merpati, Garuda Indonesia, Sriwijaya Air, Lion Air, Mandala Air, Trigana Air, KALSTAR, Trans Nusa, Sky Air,Indonesia Air dan Express Air . Untuk Airline lain (internasional) dalam proses penambahan di sistem Kami. Kami akan informasikan kepada Member Personal Agen Kami jika terjadi penambahan coverage Airline.</li>
										 
										<li><span class="judul18">Dengan melakukan Booking apakah artinya Saya sudah mendapatkan kursi?</span><br />
										 
										jawab: Belum. Booking belum merupakan komitmen yang mengikat dan bukan kepastian Anda mendapatkan kursi karena status Booking ditentukan oleh Time Limit (30 menit, 1 Jam, 2 Jam, dsb). Dalam Time Limit, status Booking Anda adalah 'Hold'. Jika melewati Time Limit Anda belum melakukan proses Issue, maka Booking tersebut akan hangus atau 'Cancel by Time Limit (CTL)'</li>
										 
										<li><span class="judul18">Jika Status Booking Saya berubah menjadi CTL, apa yang terjadi ?</span><br />
										 
										jawab: CTL adalah kepanjangan dari "Canceled by Time Limit", Anda harus mengulang lagi proses Search dan Booking jika Ingin mendapatkan kursi yang sama (jika masih tersedia). Karenanya segera lakukan Issue sebelum Time Limit berakhir</li>
									</ol>
								</p>
							 
							  
								<p align="justify"><span class="judul18">Issue Ticket
										</span>
									<ol>
								 
										<li><span class="judul18">Mengapa Saya harus Issue Tiket?</span><br />
										 
										jawab: Issue tiket adalah sebuah tahap mengubah status booking menjadi tiket yang dapat digunakan oleh calon penumpang untuk Check-In. Tahap ini melibatkan transaksi pembayaran sebagai konfirmasi</li>
										 
										<li><span class="judul18">Bagaimana caranya agar Saya bisa Issue Tiket ?</span><br />
										 
										jawab: Karena Issue Tiket melibatkan pembayaran, maka Anda diwajibkan untuk membayar menggunakan deposit, transfer atau Direct Debit Mandiri sesuai jumlah yang tercantum dalam hasil perhitungan.</li>
									</ol>
								</p>
							</div>
						</div>
					</div>
				<!-- KONTEN end -->
				</div>
			</div>