<!-- KOLOM 2 mulai -->
				<div id="kolom2<?php echo $column;?>">
					<div id="tentang">
						<!-- HEADER tentang mulai -->
						<div id="headertentang">
							<div id="headerpaket-ki"></div>
							<div id="headertentang-tgh">Selamat datang di <span class="headerpakettext">HELLOTRAVELER</span></div>
							<div id="headerpaket-ka"></div>
							<div id="headertentanggaris"></div>
						</div>
						<!-- HEADER tentang end -->
						<div id="tentangisi">Hello traveler adalah travel operator yang memberikan berbagai pilihan dan solusi perjalanan anda. Baik perjalanan domestik maupun internasional. Selain paket-paket yang telah kami sediakan, tim Hello traveler siap memberikan konsultasi dan solusi paket-paket perjalanan yang belum ada.<br />
						Hello traveler juga memberikan pelayanan terbaik dalam pemesanan tiket penerbangan dan kereta api.<br /><br />
						Dengan berbagai kemudahan yang kami berikan, Selamat menikmati perjalanan anda, biarkan kami yang mengurus "semuanya"...
						</div>
						<div id="banner1"> <img src="<?php echo IMAGES_DIR;?>/banner-umroh.jpg" /> </div>
						<div id="banner1" style="margin-top:15px"> <img src="<?php echo IMAGES_DIR;?>/banner-f1.jpg" /> </div>
						<div id="banner1" style="margin-top:15px"> <img src="<?php echo IMAGES_DIR;?>/banner-motogp.jpg" /> </div>
						<!-- AGEN mulai -->
						<div id="promopesawat">
							<!-- HEADER promo mulai -->
							<div id="headerpaket">
								<div id="headerpaket-ki"></div>
								<div id="headeragen-tgh">MENJADI AGEN <span class="headerpakettext">HELLO TRAVELER</span></div>
								<div id="headerpaket-ka"></div>
								<div id="headeragengaris"></div>
							</div>
							<!-- HEADER promo end -->
							<div id="agen2">
								<div id="agenisi">
									<div class="container-510">
										<!--<span class="container-header-blue container-header-radius5">WHY YUKTRAVEL</span>-->
										<div id="whyyuktravel" class="container-background-blue">
											<div class="container-border-blue">
												Banyak yang menawarkan peluang menjadi agen tiket pesawat. Ada yang menjanjikan nilai paket yang lebih murah dengan keuntungan besar, tetapi faktanya masih banyak keluhan soal sistem pemesanan tiket yang pada akhirnya merugikan konsumen. Hello Traveler hadir dengan sistem yang memahami permasalahan di keagenan lain dan memperbaruinya menjadi sistem yang memudahkan dan memberikan kepuasan pada konsumen Anda.
												<ul>
													<li>Hanya dengan 2,5jt Rupiah sudah bisa mendapatkan system online, pesawat, hotel, tour, transport. anda telah mendapatkan semua hak keagenan</li>
													<li>Tidak di pungut biaya bulanan</li>
													<li>Full online ke masing masing system airline.</li>
													<li>Pembayaran tiket sebesar NTA**</li>
													<li> Pasif Income dari Sub Agen sebesar  5000 per transaksi Sub Agen</li>
													<li>Bisa menggunakan fasilitas online lainnya seperti Tiket Kereta Api, pemesanan hotel, transport, tour.</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- AGEN end -->
					</div>
				</div>
				<!-- KOLOM 2 end -->
				